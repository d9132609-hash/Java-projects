import java.util.Objects;
import java.util.Scanner;

public class MyCalculater {
    private Scanner scanner = new Scanner(System.in);


    public void calculater() {
        System.out.println("Welcome to my calculater");
        label:
        while (true) {

            System.out.println("1-sum \n2-sub\n3-mul\n4-div\n5-exit");
            System.out.print("pleas enter your operation:");
            String operation = scanner.next();
            if (operation.equals("5")) {
                if (exit().equals("yes")) {
                    break;
                }

            }
            System.out.print("Enter your number1:");
            int number1 = scanner.nextInt();
            System.out.print("Enter your number2:");
            int number2 = scanner.nextInt();

            switch (operation) {

                case "1" -> System.out.println("Your result is :" + (number1 + number2));
                case "2" -> System.out.println("Your result is :" + (number1 - number2));
                case "3" -> System.out.println("Your result is :" + (number1 * number2));
                case "4" -> System.out.println("Your result is :" + (number1 / number2));
                default -> {
                    System.out.println("excuse me your operation is not defined");
                    continue;
                }
            }
            if (Objects.equals(question(), "no")) {
                break;

            }

        }

    }


    private String question() {
        String question;
        while (true) {
            System.out.print("Can you continue?(yes/no)");
            question = scanner.next().toLowerCase();
            if (question.equals("no")) {
                break;

            } else if (question.equals("yes")) {
                break;

            } else {
                System.out.println("please enter your yes or no");
            }
            System.out.println(question);

        }

        return question;

    }

    private String exit() {
        String question;
        while (true) {
            System.out.print("are you exit?(yes/no)");
            question = scanner.next().toLowerCase();
            if (question.equals("no")) {
                break;

            } else if (question.equals("yes")) {
                break;

            } else {
                System.out.println("please enter your yes or no");
            }

        }
        return question;

    }

}

