package MyDataBuilding;

public class MyAVLTree {
    private class AVLNode {
        private int value;
        private AVLNode leftChild;
        private AVLNode rightChild;
        private int height;

        private AVLNode(int value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return "value " + value;
        }
    }

    private AVLNode root;

    public void insert(int value) {
        root = insert(root, value);
    }

    private AVLNode insert(AVLNode node, int value) {
        if (node == null) {
            return new AVLNode(value);

        } else if (value < node.value) {
            node.leftChild = insert(node.leftChild, value);

        } else {
            node.rightChild = insert(node.rightChild, value);

        }
        setHeight(node);

        node = balance(node);
        return node;
    }

    private int height(AVLNode node) {
        return node == null ? -1 : node.height;
    }

    private boolean isLeft(AVLNode node) {
        return balanceFactor(node) > 1;
    }

    private boolean isRight(AVLNode node) {
        return balanceFactor(node) < -1;
    }

    private int balanceFactor(AVLNode node) {
        return node == null ? 0 : height(node.leftChild) - height(node.rightChild);
    }

    private AVLNode balance(AVLNode node) {
        if (isLeft(node)) {
            if (balanceFactor(node.leftChild) < 0) {
                node.leftChild = leftRotation(node.leftChild);

            }
            return rightRotation(node);

        }
        if (isRight(node)) {
            if (balanceFactor(node.rightChild) < 0) {
                node.rightChild = leftRotation(node.rightChild);

            }
            return leftRotation(node);

        }
        return node;


    }

    private AVLNode leftRotation(AVLNode root) {
        var newRoot = root.rightChild;
        root.rightChild = newRoot.leftChild;
        newRoot.leftChild = root;
        setHeight(root);
        setHeight(newRoot);
        return newRoot;
    }

    private AVLNode rightRotation(AVLNode root) {
        var newRoot = root.leftChild;
        root.leftChild = newRoot.rightChild;
        newRoot.rightChild = root;
        setHeight(root);
        setHeight(newRoot);
        return newRoot;
    }

    private void setHeight(AVLNode node) {
        node.height = Math.max(height(node.leftChild), height(node.rightChild)) + 1;

    }
}
