package MyDataBuilding;

public class MyArray {
    private int[] items;
    private int count;

    public MyArray(int length) {
        this.items = new int[length];
    }

    public void print() {
        for (int i = 0; i < count; i++) {
            System.out.println(items[i]);

        }

    }

    public void insert(int item) {
        if (count >= items.length) {
            int[] newItem = new int[items.length * 2];
            for (int i = 0; i < count; i++) {
                newItem[i] = items[i];

            }
            items = newItem;


        }
        items[count++] = item;

    }

    public void removeAt(int index) {
        if (index < 0 || index > count) {
            throw new IllegalArgumentException("error");

        }
        for (int i = index; i < count; i++) {
            items[i] = items[i + 1];

        }
        count--;

    }

    public int indexOf(int index) {
        for (int i = 0; i < count; i++) {
            if (items[i] == index) {
                return i;
            }

        }
        return -1;
    }
}
