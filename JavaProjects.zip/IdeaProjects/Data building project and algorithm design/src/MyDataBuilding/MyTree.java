package MyDataBuilding;

public class MyTree {
    private class Node {
        private int value;
        private Node leftChild;
        private Node rightChild;

        private Node(int value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return "Node " + value;
        }
    }

    private Node root;

    public void insert(int value) {
        var node = new Node(value);
        if (root== null) {
            root=node;
            return;


        }
        var current = root;
        while (true) {
            if (value < current.value) {
                if (current.leftChild == null) {
                    current.leftChild=node;
                    break;

                }
                current = current.leftChild;
            } else {
                if (current.rightChild == null) {
                    current.rightChild = node;
                    break;

                }
                current = current.rightChild;
            }

        }
    }


    public boolean find(int value) {
        var current = root;
        while (current != null) {
            if (value < current.value) {
                current = current.leftChild;

            } else if (value > current.value) {
                current = current.rightChild;

            } else {
                return true;
            }
        }
        return false;
    }

    public void inOrder() {
        inOrder(root);
    }

    private void inOrder(Node node) {
        if (node == null) {
            return;

        }
        System.out.println(node.leftChild);
        System.out.println(node.value);
        System.out.println(node.rightChild);
    }

    public void preOrder() {
        inOrder(root);
    }

    private void preOrder(Node node) {
        if (node == null) {
            return;

        }
        System.out.println(node.value);
        System.out.println(node.leftChild);
        System.out.println(node.rightChild);
    }

    public void postOrder() {
        postOrder(root);
    }

    private void postOrder(Node node) {
        if (node == null) {
            return;

        }
        System.out.println(node.leftChild);
        System.out.println(node.rightChild);
        System.out.println(node.value);
    }

    public int height() {
        return height(root);
    }

    private int height(Node node) {
        if (node.leftChild == null && node.rightChild == null) {
            return 0;

        }
        return 1 + Math.max(height(node.leftChild), height(node.rightChild));
    }

    public int minValue() {
        return minValue(root);
    }

    private int minValue(Node node) {
        if (node.leftChild == null && node.rightChild == null) {
            return node.value;


        }
        var left = minValue(node.leftChild);
        var right = minValue(node.rightChild);
        return Math.min(Math.min(left, right), node.value);
    }

    public int minBinary() {
        var z = root;
        var last = z;
        while (z == null) {
            last = z;
            z = z.leftChild;

        }
        return last.value;

    }

    public boolean equalsTree(MyTree other) {
        return equalsTree(root, other.root);
    }

    private boolean equalsTree(Node first, Node second) {
        if (first == null && second == null) {
            return true;

        }
        if (first != null && second != null) {
            return first.value == second.value && equalsTree(first.leftChild, second.leftChild)
                    && equalsTree(first.rightChild , second.rightChild);

        }
        return false;

    }

    public boolean bst() {
        return bst(root, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    private boolean bst(Node node, int min, int max) {
        if (node == null) {
            return true;

        }
        if (node.value < min || node.value > max) {
            return false;

        }
        return bst(node.leftChild, min, node.value - 1) && bst(node.rightChild, node.value + 1, max);
    }

    public void distanceRoot(int n) {
        distanceRoot(root, n);
    }

    private void distanceRoot(Node node, int n) {
        if (node == null) {
            return;

        }
        if (n == 0) {
            System.out.println(node.value);
            return;

        }
        distanceRoot(node.leftChild, n - 1);
        distanceRoot(node.rightChild, n - 1);
    }

    public void levelOrder() {
        for (int i = 0; i < height(); i++) {
            distanceRoot(i);

        }
    }


}


