package MyDataBuilding;

import java.util.HashMap;
import java.util.Map;

public class MyTrie {
    public class Node{
        private char value;
        private Map<Character,Node> children=new HashMap<>();
        private boolean isEndOfWord;

        public Node(char value) {
            this.value = value;
        }

        private boolean hasChild(char ch){
            return children.containsKey(ch);
        }
        private void addChild(char ch){
            children.put(ch,new Node(ch));
        }
        private Node getChild(char ch){
            return children.get(ch);
        }
        private Node[] getChildren(){
            return children.values().toArray(new Node[0]);
        }
        private boolean hasChildren(){
            return !children.isEmpty();
        }
        private void removeChild(char ch){
            children.remove(ch);

        }

    }
    private Node root=new Node(' ');
    public void insert(String name){
        var current=root;
        if (current == null) {
            throw new IllegalArgumentException("null is not name");
        }
        for (var ch:name.toCharArray()){
            if (!current.hasChild(ch)) {
                current.addChild(ch);

            }
            current=current.getChild(ch);
        }
        current.isEndOfWord=true;

    }
    public boolean contains(String name){
        var current=root;
        if (current == null) {
            throw new IllegalArgumentException("null is not name");
        }
        for (var ch:name.toCharArray()){
            if (!current.hasChild(ch)) {
                return false;

            }

        current=current.getChild(ch);
    }
        return current.isEndOfWord;



    }
    public void postNavigation(){
        postNavigation(root);

    }

    private void postNavigation(Node node) {
        for (var child: node.getChildren()) {
            postNavigation(child);

        }
        System.out.println(node.value);
    }
    public void priNavigation(){
        priNavigation(root);
    }
    private void priNavigation(Node node) {
        System.out.println(node.value);
        for (var child: node.getChildren()) {
            postNavigation(child);

        }
    }
    public void remove(String name){
        remove(root,name,0);
    }

    private void remove(Node node, String name, int index) {
        if (index == name.length()) {
            node.isEndOfWord=false;
            return;

        }
        var ch=name.charAt(index);
        var child=node.getChild(ch);
        if (child == null) {
            throw new IllegalArgumentException("you are not this name");

        }
        remove(child,name,index+1);
        if (!child.hasChild(ch)&&!child.isEndOfWord) {
            node.removeChild(ch);

        }

    }

}
