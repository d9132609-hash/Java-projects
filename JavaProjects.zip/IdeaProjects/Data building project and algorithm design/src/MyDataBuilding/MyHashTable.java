package MyDataBuilding;

import java.util.*;

public class MyHashTable {
    private class Entry {
        private int key;
        private String value;

        private Entry(int key, String value) {
            this.key = key;
            this.value = value;
        }
    }

    private LinkedList<Entry>[] array = new LinkedList[5];

    public char theFirstNonRepeatingCharacter(String str) {
        var map = new HashMap<Character, Integer>();
        var chars = str.toCharArray();
        for (char ch : chars) {
            var count = map.containsKey(ch) ? map.get(ch) : 0;
            map.put(ch, count + 1);
        }
        for (char ch : chars) {
            if (map.get(ch) == 1) {
                return ch;
            }
        }
        return Character.MIN_VALUE;
    }

    public char theFirstRepeatingCharacter(String str) {
        var set = new HashSet<Character>();
        var chars = str.toCharArray();
        for (char ch : chars) {
            if (set.contains(ch)) {
                return ch;
            }
            set.add(ch);

        }
        return Character.MIN_VALUE;
    }

    public void put(int key, String value) {
        var index = hash(key);
        array[index] = new LinkedList<>();
        var bracket = array[index];
        for (var ch : bracket) {
            if (ch.key == key) {
                ch.value = value;
                return;
            }

        }
        var ch = new Entry(key, value);
        bracket.addLast(ch);

    }

    public String get(int key) {
        var index = hash(key);
        var bracket = array[index];
        if (bracket != null) {
            for (var ch : bracket) {
                if (ch.key == key) {
                    return ch.value;

                }
            }


        }
        return null;

    }

    public void remove(int key) {
        var index = hash(key);
        var bracket = array[index];
        if (bracket == null) {
            throw new IllegalArgumentException("you don't have key");
        }
        for (var ch : bracket) {
            if (ch.key == key) {
                bracket.remove(ch);

            }
        }
        throw new IllegalArgumentException("you don't have key");

    }

    public int hash(int key) {
        return key % array.length;
    }


}
