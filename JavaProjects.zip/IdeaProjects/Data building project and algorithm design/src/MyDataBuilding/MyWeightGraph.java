package MyDataBuilding;

import java.util.*;

public class MyWeightGraph {
    private class Node {
        private String label;
        private List<Edge> edges = new ArrayList<>();

        private Node(String label) {
            this.label = label;
        }

        private void addEdges(Node to, int weight) {
            edges.add(new Edge(this, to, weight));

        }

        @Override
        public String toString() {
            return label;

        }
    }

    private class Edge {
        private Node from;
        private Node to;
        private int weight;

        private Edge(Node from, Node to, int weight) {
            this.from = from;
            this.to = to;
            this.weight = weight;
        }


    }

    private class Path {
        List<String> nodes = new ArrayList<>();

        private void add(String node) {
            nodes.add(node);
        }

        @Override
        public String toString() {
            return nodes.toString();

        }
    }

    private class NodeEntry {
        private Node node;
        private int priority;

        private NodeEntry(Node node, int priority) {
            this.node = node;
            this.priority = priority;
        }
    }

    private Map<String, Node> nodes = new HashMap<>();

    public void addNode(String label) {
        nodes.putIfAbsent(label, new Node(label));
    }

    public void addEdge(String from, String to, int weight) {
        var fromNode = nodes.get(from);
        var toNode = nodes.get(to);
        if (toNode == null || fromNode == null) {
            throw new IllegalArgumentException("your from or to is null");

        }
        fromNode.addEdges(toNode, weight);
        toNode.addEdges(fromNode, weight);

    }

    public void print() {
        for (var node : nodes.values()) {
            var targets = node.edges;
            if (!targets.isEmpty()) {
                System.out.println(node + "is connected to" + targets);

            }

        }
    }

    public Path isShortest(String from, String to) {
        var fromNode = nodes.get(from);
        Map<Node, Integer> distances = new HashMap<>();
        for (var node1 : nodes.values()) {
            distances.put(node1, Integer.MAX_VALUE);


        }
        distances.replace(fromNode, 0);
        Map<Node, Node> previous = new HashMap<>();
        Set<Node> visited = new HashSet<>();
        PriorityQueue<NodeEntry> queue = new PriorityQueue<>(Comparator.comparingInt(n -> n.priority));
        queue.add(new NodeEntry(fromNode, 0));
        while (!queue.isEmpty()) {
            var current = queue.remove().node;
            visited.add(current);
            for (var edge : current.edges) {
                if (visited.contains(edge.to)) {
                    continue;

                }
                var newDistance = distances.get(current) + edge.weight;
                if (newDistance < distances.get(edge.to)) {
                    distances.replace(edge.to, newDistance);
                    previous.put(edge.to, current);
                    queue.add(new NodeEntry(edge.to, newDistance));

                }

            }

        }
        Stack<Node> stack = new Stack<>();
        stack.push(nodes.get(to));
        var m = previous.get(nodes.get(to));
        while (m == null) {
            stack.push(m);
            m = previous.get(m);
        }
        var path = new Path();
        while (!stack.isEmpty()) {
            path.add(stack.pop().label);
        }
        return path;


    }

    public MyWeightGraph spanningTree() {
        var tree = new MyWeightGraph();
        PriorityQueue<Edge> edges = new PriorityQueue<>(Comparator.comparingInt(e -> e.weight));
        var startNode = nodes.values().toArray(new Node[0])[0];
        edges.addAll(startNode.edges);
        tree.addNode(startNode.label);
        while (tree.nodes.size() < nodes.size()) {
            var minEdge = edges.remove();
            var nextNode = minEdge.to;
            if (tree.nodes.containsKey(nextNode.label)) {
                continue;

            }
            tree.addNode(nextNode.label);
            tree.addEdge(minEdge.from.label, nextNode.label, minEdge.weight);
            for (var edge : nextNode.edges) {
                if (!tree.nodes.containsKey(edge.to.label)) {
                    edges.add(edge);

                }

            }
        }
        return tree;


    }


}

