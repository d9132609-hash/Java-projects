package MyDataBuilding;

import java.util.*;

public class MyGraph {
    private class Node {
        private String label;

        private Node(String label) {
            this.label = label;
        }

        public String toString() {
            return label;
        }
    }

    private Map<String, Node> nodes = new HashMap<>();
    private Map<Node, List<Node>> adjacencyList = new HashMap<>();

    public void addNode(String label) {
        var node = new Node(label);
        nodes.putIfAbsent(label, node);
        adjacencyList.putIfAbsent(node, new ArrayList<>());

    }

    public void addEdge(String from, String to) {
        var fromNode = nodes.get(from);
        var toNode = nodes.get(to);
        if (toNode == null || fromNode == null) {
            throw new IllegalArgumentException();

        }
        adjacencyList.get(fromNode).add(toNode);

    }

    public void print() {
        for (var source : adjacencyList.keySet()) {
            var targets = adjacencyList.get(source);
            if (!targets.isEmpty()) {
                System.out.println(source + "is connected to" + targets);

            }
        }
    }

    public void removeTo(String label) {
        var node = nodes.get(label);
        if (node == null) {
            throw new IllegalArgumentException();

        }
        for (var n : adjacencyList.keySet()) {
            adjacencyList.get(n).remove(node);
            nodes.remove(node);
        }
    }

    public void removeEdge(String from, String to) {
        var fromNode = nodes.get(from);
        var toNode = nodes.get(to);
        if (toNode == null || fromNode == null) {
            throw new IllegalArgumentException("you are not condition");

        }
        adjacencyList.get(fromNode).remove(toNode);


    }

    public void depthFirst(String root) {
        depthFirst(nodes.get(root), new HashSet<>());
    }

    private void depthFirst(Node node, Set<Node> visited) {
        visited.add(node);
        for (var n : adjacencyList.get(node)) {
            if (!visited.contains(n)) {
                depthFirst(n, visited);

            }

        }
    }

    public void etration(String root) {
        var node = nodes.get(root);
        if (node == null) {
            return;
        }
        var stack = new Stack<>();
        Set<Node> visited = new HashSet<>();
        stack.push(node);
        while (!stack.empty()) {
            var current = stack.pop();
            if (visited.contains(current)) {
                continue;

            }
            System.out.println(current);
            for (var neighbor : adjacencyList.get(current)) {
                if (visited.contains(neighbor)) {
                    stack.push(neighbor);

                }
            }
        }
    }

    public void breathFirst(String root) {
        var node = nodes.get(root);
        if (node == null) {
            return;
        }
        Queue<Node> queue = new ArrayDeque<>();
        Set<Node> visited = new HashSet<>();
        queue.add(node);
        while (!queue.isEmpty()) {
            var current = queue.remove();
            if (visited.contains(current)) {
                continue;

            }
            System.out.println(current);
            visited.add(current);
            for (var neighbor : adjacencyList.get(current)) {
                if (!visited.contains(neighbor)) {
                    queue.add(neighbor);

                }
            }

        }


    }

    public boolean hasCircle() {
        Set<Node> all = new HashSet<>();
        all.addAll(nodes.values());
        Set<Node> visiting = new HashSet<>();
        Set<Node> visited = new HashSet<>();
        while (!all.isEmpty()) {
            var current = all.toArray(new Node[0])[0];
            if (hasCircle(current, all, visiting, visited)) {
                return true;

            }
        }
        return false;
    }

    private boolean hasCircle(Node node, Set<Node> all, Set<Node> visiting, Set<Node> visited) {
        all.remove(node);
        visiting.add(node);
        for (var neighbor : adjacencyList.get(node)) {
            if (visited.contains(neighbor)) {
                continue;

            }
            if (visiting.contains(neighbor)) {
                return true;

            }
            var result = hasCircle(neighbor, all, visiting, visited);
            if (result) {
                return true;

            }
        }
        return false;

    }

}
