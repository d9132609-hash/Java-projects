package MyDataBuilding;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Queue;
import java.util.Stack;

public class MyQueue {
    private int[] items;
    private int count;
    private int rear;
    private int front;

    public MyQueue(int length) {
        this.items = new int[length];
    }

    public void add(int item) {
        if (this.count == this.items.length) {
            int[] newItems = new int[this.items.length * 2];

            for (int i = 0; i < this.count; ++i) {
                newItems[i] = this.items[i];
            }

            this.items = newItems;
        }

        this.items[this.rear++] = item;
        ++this.count;
    }

    public int remove() {
        int item = this.items[this.front];
        this.items[this.front++] = 0;
        --this.count;
        return item;
    }

    public boolean isEmpty() {
        return this.count == 0;
    }

    public void addArrayCircle(int item) {
        if (this.count == this.items.length) {
            int[] newItems = new int[this.items.length * 2];

            for (int i = 0; i < this.count; ++i) {
                newItems[i] = this.items[i];
            }

            this.items = newItems;
        }

        this.rear = (this.rear + 1) % this.items.length;
        this.items[this.rear] = item;
        ++this.count;
    }

    public int removeArrayCircle() {
        int item = this.items[this.front];
        this.items[this.front] = 0;
        this.front = (this.front + 1) % this.items.length;
        --this.count;
        return item;
    }

    public void addForStack(int item) {
        Stack<Integer> stack1 = new Stack();
        stack1.push(item);
    }

    public int removeForStack() {
        Stack<Integer> stack1 = new Stack();
        Stack<Integer> stack2 = new Stack();
        if (stack1.empty() && stack2.empty()) {
            throw new IllegalArgumentException("your queue is empty");
        } else {
            if (stack2.empty()) {
                while (!stack1.empty()) {
                    stack2.push((Integer) stack1.pop());
                }
            }

            return (Integer) stack2.pop();
        }
    }

    public void addPriorityQueue(int item) {
        if (this.count == this.items.length) {
            int[] newItems = new int[this.items.length * 2];

            for (int i = 0; i < this.count; ++i) {
                newItems[i] = this.items[i];
            }

            this.items = newItems;
        }

        for (int i = this.count - 1; i >= 0 && this.items[i] > item; --i) {
            this.items[i + 1] = this.items[i];
        }

    }

    public int removePriorityQueue() {
        if (this.count == 0) {
            throw new IllegalArgumentException("your queue is empty");
        } else {
            return this.items[this.count - 1];
        }
    }

    public String toString() {
        return Arrays.toString(this.items);
    }

    public void reverse(Queue<Integer> queue) {
        Stack<Integer> stack = new Stack();

        while (!queue.isEmpty()) {
            stack.push((Integer) queue.remove());
        }

        while (!stack.empty()) {
            queue.add((Integer) stack.pop());
        }

    }
}

