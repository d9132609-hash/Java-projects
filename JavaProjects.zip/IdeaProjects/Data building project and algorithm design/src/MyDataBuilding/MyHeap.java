package MyDataBuilding;

public class MyHeap {
    private int[] items;
    private int size;

    public MyHeap(int lenght) {
        this.items = new int[lenght];
    }

    public void insert(int value) {
        if (size == items.length) {
            var newItems = new int[size * 2];
            for (int i = 0; i < size; i++) {
                newItems[i] = items[i];

            }
            items = newItems;

        }
        items[size++] = value;
        bubbleUp();
    }

    private void bubbleUp() {
        var index = size - 1;
        while (index > 0 && items[index] > items[parent(index)]) {
            swap(index, parent(index));
            index = parent(index);

        }
    }


    private int parent(int index) {
        return index - 1;
    }

    public int remove() {
        if (size == 0) {
            throw new IllegalStateException();

        }
        var root = items[0];
        items[0] = items[--size];
        var index = 0;
        while (index <= size && !isParent(index)) {
            var bigChild = bigChild(index);
            swap(index, bigChild);
            index = bigChild;
        }
        return root;
    }

    private void swap(int first, int second) {
        int temporary = items[first];
        items[first] = items[second];
        items[second] = temporary;

    }

    private int left(int index) {
        return index * 2 + 1;
    }

    private boolean presenceLeftChild(int index) {
        return left(index) <= size;
    }

    private int right(int index) {
        return index * 2 + 2;
    }

    private boolean presenceRightChild(int index) {
        return right(index) <= size;
    }

    private int rightChild(int index) {
        return items[right(index)];
    }

    private int leftChild(int index) {
        return items[left(index)];
    }


    private boolean isParent(int index) {
        if (!presenceLeftChild(index)) {
            return true;

        } else if (!presenceRightChild(index)) {
            return items[index] >= leftChild(index);

        }
        return items[index] >= leftChild(index) || items[index] >= rightChild(index);
    }

    private int bigChild(int index) {
        if (!presenceLeftChild(index)) {
            return index;

        } else if (!presenceRightChild(index)) {
            return left(index);

        }
        return (leftChild(index) > rightChild(index)) ? left(index) : right(index);
    }

    public int[] sort(int[] items) {
        var numbers = items;
        for (var number : numbers) {
            insert(number);
        }
        for (int i = numbers.length - 1; i > 0; i--) {
            numbers[i] = remove();

        }
        return numbers;
    }

    public void heapify(int[] array) {
        for (int i = 0;i<array.length;i++                       ) {
            heapify(array, i);
        }
    }

    private void heapify(int[] array, int index) {
        var n = index;
        var left = index * 2 + 1;
        var right = index * 2 + 2;
        if (left < array.length && array[left] > array[n]) {
            n = left;
        }
        if (right < array.length && array[right] > array[n]) {
            n = right;
        }
        if (index == n) {
            return;
        }
        swap2(array, index, n);
        heapify(array, n);
    }

    private void swap2(int[] items, int first, int second) {
        int temporary = items[first];
        items[first] = items[second];
        items[second]=temporary;


    }
    public int getK(int[]array,int k){
        for (var number:array){
            insert(number);
        }
        for (int i = 0; i < k-1; i++) {
            remove();

        }
        return max();
    }

    private int max() {
        if (size == 0) {
            throw new IllegalStateException();

        }
        else {
            return items[0];
        }
    }
}
