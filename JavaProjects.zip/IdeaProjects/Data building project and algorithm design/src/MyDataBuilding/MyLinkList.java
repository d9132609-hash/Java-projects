package MyDataBuilding;

import java.util.NoSuchElementException;

public class MyLinkList {
    private class Node {
        private int value;
        private Node next;

        private Node(int value) {
            this.value = value;
        }
    }

    private Node first;
    private Node last;
    private int size;

    public void addLast(int item) {
        var items = new Node(item);
        if (first == null) {
            first = last = items;

        } else {
            last.next = items;
            last = items;
        }
        size++;

    }

    public int indexOf(int item) {
        int index = 0;
        var z = first;
        while (z != null) {
            if (z.value == item) {
                return index;
            }
            z = z.next;
            index++;
        }
        return -1;
    }

    public boolean contains(int item) {
        return indexOf(item) != -1;
    }

    public void addFirst(int item) {
        var items = new Node(item);
        if (first == null) {
            first = last = items;

        } else {
            items.next = first;
            first = items;
        }
        size++;

    }

    public void removeFirst() {
        if (first == null) {
            throw new NoSuchElementException();

        }
        if (first == last) {
            first = last = null;
            return;

        }
        var a = first.next;
        first.next = null;
        first = a;
        size--;
    }


    public void removeLast() {

        if (first == null) {
            throw new NoSuchElementException();

        }
        if (first == last) {
            first = last = null;
            return;

        }
        var previous = getPrevious(last);

        last = previous;
        last.next = null;

        size--;

    }

    private Node getPrevious(Node node) {
        var z = first;
        while (z != null) {
            if (z.next == node) {
                return z;

            }
            z = z.next;
        }
        return null;

    }

    public int size() {
        return size;
    }

    public int[] toArray() {
        int[] array = new int[size];
        var current = first;
        int index = 0;
        while (current != null) {
            array[index++] = current.value;
            current = current.next;


        }
        return array;
    }

    public void responsive() {
        var m = first;
        var n = first.next;
        last = first;
        last.next = null;
        while (n != null) {
            var r = n.next;
            n.next = m;
            m = n;
            n = r;
        }
        first = m;
    }

    public int itemK(int k) {
        var item1 = first;
        var item2 = first;
        for (int i = 0; i < k - 1; i++) {
            item1 = item1.next;

        }
        while (item1 != last) {
            item2 = item2.next;
            item1 = item1.next;
        }
        return item2.value;
    }
}

