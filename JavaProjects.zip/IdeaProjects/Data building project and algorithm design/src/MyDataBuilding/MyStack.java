package MyDataBuilding;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;

public class MyStack {
    private int[] items;
    private int count;
    private final List<Character> RIGHTLIST = Arrays.asList(')', ']', '}', '>');
    private final List<Character> LEFTLIST = Arrays.asList('(', '[', '{', '<');

    public MyStack(int length) {
        this.items = new int[length];
    }

    public void push(int item) {
        if (count == items.length) {
            int[] newItems = new int[count * 2];
            for (int i = 0; i < count; i++) {
                newItems[i] = items[i];

            }
            items = newItems;

        }
        items[count++] = item;

    }

    public int pop() {
        if (count == 0) {
            throw new IllegalArgumentException("لیست مورد نظر شما خالی است");

        }
        return items[--count];

    }

    public int peek() {
        if (count == 0) {
            throw new IllegalArgumentException("لیست مورد نظر شما خالی است");

        }
        return items[count - 1];


    }

    public boolean isEmpty() {
        return count == 0;
    }

    @Override
    public String toString() {
        var content = Arrays.copyOfRange(items, 0, count);
        return Arrays.toString(content);
    }

    public String reverse(String text) {
        if (text == null) {
            throw new IllegalArgumentException("کلمه مورد نظر شما خالی است");

        }
        var stack = new Stack<Character>();
        for (char ch : text.toCharArray()) {
            stack.push(ch);
        }

        var name = new StringBuffer();
        while (!stack.empty()) {
            name.append(stack.pop());
        }
        return name.toString();
    }

    public boolean balanced(String text) {
        if (text == null) {
            throw new IllegalArgumentException("کلمه مورد نظر شما خالی است");

        }
        Stack<Character> stack = new Stack<>();
        for (char ch : text.toCharArray()) {
            if (leftBalanced(ch)) {
                stack.push(ch);
            }
            if (rightBalanced(ch)) {
                if (stack.empty()) {
                    return false;
                }
                var top = stack.pop();
                if (balanced1And2(ch, top)) {

                    return false;
                }
            }

        }
        return stack.empty();

    }

    private boolean leftBalanced(char ch) {
        return LEFTLIST.contains(ch);

    }

    private boolean rightBalanced(char ch) {
       return RIGHTLIST.contains(ch);



    }

    private boolean balanced1And2(char left, char right) {
        return LEFTLIST.indexOf(left) == RIGHTLIST.indexOf(right);

    }


}
