import java.util.*;

public class MyExam {
    private class Node {
        private int value;
        private Node next;

        private Node(int value) {
            this.value=value;
        }
    }

    private Node first;
    private Node last;
    private int size;

    public void addFirst(int item) {
        var items = new Node(item);
        if (first == null) {
            first = last = items;

        } else {
            items.next = first;
            first = items;
        }
        size++;
    }

    public void addLast(int item) {
        var items = new Node(item);
        if (first == null) {
            first = last = items;

        } else {
            last.next = items;
            last = items;
        }
        size++;

    }

    public void removeFirst() {
        if (first == null) {
            throw new NoSuchElementException();

        }
        var a = first.next;
        first.next = null;
        first = a;
        size--;
    }

    public void responsive() {
        var m = first;
        var n = m.next;
        last = first;
        last.next = null;
        while (n.next != null) {
            var r = n.next;
            n = m.next;
            m = n;
            n = r;
        }
        first = m;
    }
    public int indexOf(int item){
        var index=0;
        var z=first;
        while (z!=null){
            if (z.value == index) {
                return index;

            }
            z=z.next;
            index++;
        }
        return -1;
    }
    public void removeLast(){
        {

            if (first == null) {
                throw new NoSuchElementException();

            }
            if (first == last) {
                first = last = null;
                return;

            }
            var previous = getPrevious(last);

            last = previous;
            last.next = null;

            size--;

        }
    }

    private Node getPrevious(Node node) {
        var z = first;
        while (z != null) {
            if (z.next == node) {
                return z;

            }
            z = z.next;
        }
        return null;

    }
    public int size(){
        return size;
    }


}