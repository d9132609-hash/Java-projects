import MyDataBuilding.*;

public class Main {
    public static void main(String[] args) {


















//my code linked list
        // var list=new MyLinkList();
        // list.addFirst(1);
        // list.addFirst(2);
        // list.addFirst(3);
        //list.addLast(4);
        //list.addLast(5);
        //list.addLast(6);
        //list.addLast(7);
        // list.removeLast();
        // list.removeFirst();
        //list.responsive();
        // System.out.println(list.indexOf(4));
        // System.out.println(list.contains(5));
        // System.out.println(list.itemK(3));
        //System.out.println(Arrays.toString(list.toArray()));


// my code is myArray
     //  var list=new MyExam(6);
     //   list.insert(1);
     //   list.insert(2);
     //   list.insert(3);
     //   list.insert(4);
     //   list.insert(5);
     //   list.remove(1);
     //    System.out.println(list.indexOf(4));
     //    list.print();


// my code is stacked
        // var list=new MyStack(6);
        //list.push(12);
        //list.push(14);
        //list.push(15);
        //list.push(16);
        //list.push(17);
        //list.push(18);
        //list.push(19);
        //list.push(120);
        //list.pop();
        //list.pop();
        // System.out.println(list.reverse("hi ali how are you"));
        // System.out.println(list.balanced("{ji><op)"));
        // System.out.println(list.isEmpty());
        // System.out.println(list);


        // my code HashTable
        // var list=new MyExam();
        // var x=list.theFirstNonRepeatingCharacter("hi ali i am danial");
        // var y=list.theFirstRepeatingCharacter("danial");
        // list.put(1,"mohammad");
        // list.put(2,"ali");
        // list.put(3,"danial");
        // System.out.println(x);
        // System.out.println(y);
        //  System.out.println(list.get(1));


//my code Tree
        //var list=new MyTree();
        //var list2=new MyTree();
        //  list.insert(12);
        //  list.insert(13);
        //  list.insert(14);
        // list2.insert(12);
        // list2.insert(13);
        // list2.insert(14);
        //list.postOrder();
        //System.out.println(list);
        //System.out.println(list.equalsTree(list2));








// my code MyHeap
        //  var list = new MyHeap(15);
        //  list.insert(10);
        //  list.insert(5);
        //  list.insert(18);
        //  list.insert(22);
        //  list.insert(16);
        //  list.insert(7);
        //  list.insert(8);
        //  list.remove();
        //  System.out.println("done");
        //  int[] numbers = {12, 15, 38, 5, 8, 21};
        //  list.heapify(numbers);
        //  System.out.println(Arrays.toString(numbers));
        //  System.out.println(list.getK(numbers, 1));

        //System.out.println(Arrays.toString(list.sort(numbers)));








//my code Trie
   //  var list=new MyTrie();
   //  list.insert("care");
   //  list.insert("car");
   //  list.remove("care");
   //  System.out.println(list.contains("care"));


        // my code graph
        //   var list=new MyGraph();
        //   list.addNode("a");
        //   list.addNode("b");
        //   list.addNode("c");
        //   list.addNode("d");
        //   list.addNode("e");
        //   list.addEdge("a","b");
        //   list.addEdge("b","c");
        //   list.addEdge("c","d");
        //   list.addEdge("d","a");
        //   System.out.println(list.hasCircle());
        //   list.print();









    }

}