import java.util.Objects;

public class Equals {
    private int x;
    private int y;

    @Override
    public int hashCode() {
        return Objects.hash(x,y);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Equals) {
            var e=(Equals) obj;
            return e.x==x&&e.y==y;

        }
        return false;

    }

    public Equals(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
