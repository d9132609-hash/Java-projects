public class Dad {
    public Dad(boolean x) {
        this.x = x;

    }



    private boolean x;
    public boolean y(){
        return x=true;
    }
    public boolean z(){
        return x=false;
    }

}
