import java.util.Locale;
import java.util.Scanner;

public class Area {
    private Scanner scanner = new Scanner(System.in).useLocale(Locale.ENGLISH);
    private final double PI=3.14;

    public void equilateralArea() {
        System.out.print("Enter your base:");
        double base = scanner.nextDouble();
        System.out.print("Enter your height:");
        double height = scanner.nextDouble();

        double area = base * height / 2;
        System.out.println("your equilateralArea = " + area);

    }
    public void theVolumeOfTheTotalArea(){

        System.out.print("Enter your radius Cylinder:");
        double radius = scanner.nextDouble();
        System.out.print("Enter your height Cylinder:");
        double height = scanner.nextDouble();
        double theVolumeOfTheTotalArea= 2 * PI * radius * height + 2 * PI * (Math.pow(radius, 2)) * height;
        System.out.println(STR."The volume of the total area is:\{theVolumeOfTheTotalArea}");

    }
    public void areaOfASphere(){
        System.out.print("Enter your radius Sphere:");
        double radius = scanner.nextDouble();
        double areaOfASphere = 4 * PI * Math.pow(radius, 2);
        System.out.println(STR."Area of a sphere is:\{areaOfASphere}");


    }
    public void polygonalArea(){
        System.out.print("Enter your polygon:");
        int polygon=scanner.nextInt();
        System.out.print("Enter your length polygon:");
        double lengthPolygon=scanner.nextDouble();
        double polygonalArea=(polygon*Math.pow(lengthPolygon,2))/(4+Math.tan(PI/polygon));
        System.out.println(STR."Polygon area is:\{polygonalArea}");
    }



}
