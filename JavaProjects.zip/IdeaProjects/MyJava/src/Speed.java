import java.util.Locale;
import java.util.Scanner;

public class Speed {
    private final double PI=3.14;
    private Scanner scanner = new Scanner(System.in).useLocale(Locale.ENGLISH);
    public void windWeightIndex(){
        System.out.print("Enter your wind speed:");
        double windSpeed=scanner.nextDouble();
        System.out.print("Enter your time:");
        double time=scanner.nextDouble();
        double windWeightIndex=13.12 + (0.6215 * time) - (11.37 * Math.pow(windSpeed, 0.16)) +( 0.3965 * Math.pow(windSpeed, 0.16) * time);
        System.out.println(STR." wind weight index(in 10m) is:\{windWeightIndex}");
    }
}
