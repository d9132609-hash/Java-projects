
// name = Danial mohammad taghizadeh
// student number = 402151096
import java.util.Locale;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    private final static double PI = 3.14;
    public static Scanner scanner = new Scanner(System.in).useLocale(Locale.ENGLISH);

    public static void main(String[] args) {
        System.out.print("Enter your 5 digits number please:");
        int number = scanner.nextInt();
        int originalNumber = number;
        if (number > 99999 || number < 10000) {
            System.out.println("Your comment is not in the range.");
            return;

        }
        int newNumber = 0;
        while (number > 0) {
            int digit = number % 10;
            newNumber = newNumber * 10 + digit;
            number = number / 10;

        }
        System.out.println(STR."Your number is:\{originalNumber}");
        System.out.println(STR."Your reversed number is:\{newNumber}");
        









    }


}




