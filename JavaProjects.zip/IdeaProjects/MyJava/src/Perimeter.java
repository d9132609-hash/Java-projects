import java.util.Locale;
import java.util.Scanner;

public class Perimeter {
    private final double PI= 3.14;
    private Scanner scanner = new Scanner(System.in).useLocale(Locale.ENGLISH);
    public void volumeOfTheCylinder(){
        System.out.print("Enter your radius for Cylinder:");
        double radius=scanner.nextFloat();
        System.out.print("Enter your height for Cylinder:");
        double height=scanner.nextFloat();
        double volumeOfTheCylinder=2*PI*Math.pow(radius,2)*height;
        System.out.println("Volume of the cylinder is:"+volumeOfTheCylinder);
    }
    public void volumeOfASphere(){
        System.out.print("Enter your radius Sphere:");
        double radius = scanner.nextDouble();
        double volumeOfASphere = ((double) 4 /3) * PI * Math.pow(radius, 3);
        System.out.println(STR."Area of a sphere is:\{volumeOfASphere}");
    }
}
