import java.text.NumberFormat;

public class MortgageShowClass {

    public MortgageShowClass(MortgageClass mortgageC) {
        this.mortgageC = mortgageC;
    }

    private MortgageClass mortgageC;


    public void showBalance() {
        System.out.println("your pay every month:");

        for (double balance : mortgageC.getPays()) {
            System.out.println(NumberFormat.getCurrencyInstance().format(balance));

        }
    }

    public void showMortgage() {
        double mortgage = mortgageC.mortgageMethod();
        String mortgageFormat = NumberFormat.getCurrencyInstance().format(mortgage);
        System.out.println("Enter" + mortgageFormat);
    }
}
