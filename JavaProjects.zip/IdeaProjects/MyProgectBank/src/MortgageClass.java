public class MortgageClass {


    private static final byte PERCENT = 100;
    private static final byte MONTH_IS_YEARS = 12;

    public MortgageClass(float annualInterest, int principal, byte years) {
        this.annualInterest = annualInterest;
        this.principal = principal;
        this.years = years;
    }

    private float annualInterest;
    private int principal;
    private byte years;

    public byte getYears() {
        return years;
    }

    public double mortgageMethod() {
        float monthlyInterest = getMonthlyInterest();
        int numberOfPayments = getNumberOfPayments();

        double montgage = principal * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments)) /
                (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

        return montgage;
    }

    private int getNumberOfPayments() {
        return years * MONTH_IS_YEARS;
    }

    private float getMonthlyInterest() {
        return annualInterest / PERCENT / MONTH_IS_YEARS;
    }

    public double installments(short page) {
        float monthlyInterest = getMonthlyInterest();
        float pay = getNumberOfPayments();
        double balance = principal * (Math.pow(1 + monthlyInterest, pay) - Math.pow(1 + monthlyInterest, page)) / (Math.pow(1 + monthlyInterest, pay) - 1);
        return balance;

    }

    public double[] getPays() {
        var balances = new double[getNumberOfPayments()];
        for (short month = 1; month < balances.length; month++) {
            balances[month - 1] = installments(month);

        }
        return balances;
    }


}
