import java.util.Locale;
import java.util.Scanner;

public class ValueClass {
    private  static int principal;
    public static Scanner scanner = new Scanner(System.in).useLocale(Locale.ENGLISH);
    public static double valuesMethod(String name, int min, int max) {
        double value;
        while (true) {
            System.out.print(name);
            value = scanner.nextFloat();
            if (value >= min && principal <= max) {
                break;
            }
            System.out.println("Enter your value between min and max");
        }
        return value;
    }
    public static double valuesMethod(String name) {
        return scanner.nextDouble();
    }
}