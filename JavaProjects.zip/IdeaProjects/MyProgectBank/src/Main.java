import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {

    public static void main(String[] args) {


        int principal = (int) ValueClass.valuesMethod("principal:", 1000, 1_000_000);
        int annualInterestRote = (int) ValueClass.valuesMethod("annualInterestRote:", 1, 30);
        byte years = (byte) ValueClass.valuesMethod("years:", 1, 30);
        var mortgageC=new MortgageClass(principal,annualInterestRote,years);
        var result=new MortgageShowClass(mortgageC);
        result.showMortgage();
        result.showBalance();

    }

    //my code bank in many method
   //public static Scanner scanner = new Scanner(System.in).useLocale(Locale.ENGLISH);
   //public static final byte MONTH_IS_YEARS = 12;
   //public static final byte PERCENT = 100;
   //public static int principal = 0;
   //;



   //public static void main(String[] args) {
   //    //my code bank in many method
   //    int principal= (int) valuesMethod("principal:",1000,1_000_000);
   //    int annualInterestRote= (int) valuesMethod("annualInterestRote:",1,30);
   //    byte years= (byte) valuesMethod("years:",1,30);
   //    showMortgage(principal, annualInterestRote, years);
   //    showBalance(years, principal, annualInterestRote);

   //}

   //private static void showBalance(byte years, int principal, int annualInterestRote) {
   //    System.out.println("your pay every month:");
   //    for (short month = 0; month < years *MONTH_IS_YEARS; month++) {
   //        double balance=installments(principal, annualInterestRote, years,month);
   //        System.out.println(NumberFormat.getCurrencyInstance().format(balance));

   //    }
   //}

   //private static void showMortgage(int principal, int annualInterestRote, byte years) {
   //    double mortgage=mortgageMethod(principal, annualInterestRote, years);
   //    String mortgageFormat = NumberFormat.getCurrencyInstance().format(mortgage);
   //    System.out.println("Enter"+ mortgageFormat);
   //}

   //public static double valuesMethod(String name ,int min ,int max){
   //    double value;
   //    while (true) {
   //        System.out.print(name);
   //        value = scanner.nextFloat();
   //        if (value >= min && principal <= max) {
   //            break;
   //        }
   //        System.out.println("Enter your value between min and max");
   //    }
   //    return value;
   //}
   //public static double mortgageMethod(int principal, float annualInterest,byte years){
   //    float monthlyInterest = annualInterest / PERCENT / MONTH_IS_YEARS;
   //    int numberOfPayments=years*MONTH_IS_YEARS;

   //    double montgage = principal * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments)) / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);

   //    return montgage;
   //}
   //public static double installments(int principle, float annualInterest,byte years,short page){
   //    float monthlyInterest = annualInterest / PERCENT / MONTH_IS_YEARS;
   //    float pay=years*MONTH_IS_YEARS;
   //    double balance=principle*(Math.pow(1+monthlyInterest,pay)-Math.pow(1+monthlyInterest,page))/(Math.pow(1+monthlyInterest,pay)-1);
   //    return balance;

   //}

    // my code bank by while and if
    // final byte MONTH_IS_YEARS = 12;
    // final byte PERCENT = 100;
    // int principal = 0;
    // float annualInterestRote = 0;
    // byte years = 0;
    // float monthlyInterest;
    // int numberOfPayments = 0;
    // while (true) {
    //     System.out.print("Enter your principal:");
    //     principal = scanner.nextInt();
    //     if (principal >= 1000 && principal <= 1_000_000) {
    //         break;
//
    //     }
    //     System.out.println("Enter your value between 1000 and 1_000_000");
    // }
    // while (true) {
    //     System.out.print(" Enter your annual interest rote:");
    //     annualInterestRote = scanner.nextFloat();
    //     if (annualInterestRote >= 1 && annualInterestRote <= 30) {
    //         monthlyInterest = annualInterestRote / PERCENT / MONTH_IS_YEARS;
    //         break;
//
    //     }
    //     System.out.println("Enter your value between 1 and 30");
//
//
    // }
    // while (true) {
    //     System.out.print("Enter your period(years):");
    //     years = scanner.nextByte();
    //     if (years >= 1 && years <= 30) {
    //          numberOfPayments = years * MONTH_IS_YEARS;
    //         break;
//
    //     }
    //     System.out.println("Enter your value between 1 and 30");
//
    // }
    // double montgage = principal * (monthlyInterest * Math.pow(1 + monthlyInterest, numberOfPayments)) / (Math.pow(1 + monthlyInterest, numberOfPayments) - 1);
    // String mortgage = NumberFormat.getCurrencyInstance().format(montgage);
    // System.out.println("mortgage:" + mortgage);


// my code bank in one method
    //final byte MONTH_IS_YEARS=12;
    //final byte PERCENT=100;
    //System.out.print("Enter your principal:");
    //int principal=scanner.nextInt();
    //System.out.print(" Enter your annual interest rote:");
    //float annualInterestRote=scanner.nextFloat();
    //float monthlyInterest=annualInterestRote/PERCENT/MONTH_IS_YEARS;
    //System.out.print("Enter your period(years):");
    //byte years=scanner.nextByte();
    //int numberOfPayments=years*MONTH_IS_YEARS;
    //double montgage=principal*(monthlyInterest*Math.pow(1+monthlyInterest,numberOfPayments))/(Math.pow(1+monthlyInterest,numberOfPayments)-1);
    //String mortgage=NumberFormat.getCurrencyInstance().format(montgage);
    //System.out.println("mortgage:"+mortgage);


}